import React, { useState, useEffect, useRef }  from 'react';
import $ from 'jquery';
import Axios from "axios";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Profile from '../components/Profile';
function ChallengeUpdate(props){
    const location = useLocation();
    const history = useNavigate();

    const [challenge, setChallenge] = useState(location.state.challenge);
      
      const handleChange = (e) => {
        const { name, value } = e.target;
        if (name === "thumbnail") {
          setChallenge(prevState => ({ ...prevState, [name]: e.target.files[0] }));
        } else if (name === "c_typeofverify" || name === "c_typeoffrequency") {
            setChallenge(prevState => ({ ...prevState, [name]: parseInt(value) }));
          } else {
            setChallenge(prevState => ({ ...prevState, [name]: value }));
          }
      };

      
    const updateChallenge = (challengeData) =>{
        const formData = new FormData();
        
        formData.append('thumbnail', challengeData.thumbnail);
        formData.append('c_name', challengeData.c_name);
        formData.append('c_content', challengeData.c_content);
        formData.append('c_startdate', challengeData.c_startdate);
        formData.append('c_enddate', challengeData.c_enddate);
        formData.append('c_numberofparticipants', challengeData.c_numberofparticipants);
        formData.append('c_category', challengeData.c_category);
        formData.append('c_introduction', challengeData.c_introduction);
        formData.append('c_fee', challengeData.c_fee);
        formData.append('c_numberofphoto', challengeData.c_numberofphoto);
        formData.append('c_typeofverify', challengeData.c_typeofverify);
        formData.append('c_typeoffrequency', challengeData.c_typeoffrequency);
        formData.append('c_frequency', challengeData.c_frequency);
        formData.append('c_score', challengeData.c_score);

        console.log(challengeData);

        Axios.post('http://localhost:8070/challenge/updatechallenge',formData,{
            headers : {
                'Content-Type':'multipart/form-data'
            }
        })
        .then((res)=>{
            console.log(res);
            history('/challenge');
        })
        .catch((error)=>{
            console.log(error)
        });
    }

    useEffect(()=>{
        $("#thumbnail").click(function() {
            $("#uploadInput").trigger("click");
        });
        $("#uploadInput").change(function() {

            var reader = new FileReader();
            reader.onload = function(e) {
                // 선택한 파일의 데이터 URL을 가져와서 이미지의 src로 설정
                $("#thumbnail").attr("src", e.target.result);
            }
            reader.readAsDataURL(this.files[0]);
        });
    }, []);
    return(
        <>
            {props.header}
            <div id="challenge" class="container">
                <div class="container_inner">
                    <div>
                        <ul>
                            <Profile/>
                            <li class="challenge_read">
                                <div class="read_title">
                                    <img src="/img/flag.png" alt="flag"/>
                                    <p>챌린지명 : <input type="text" name="c_name" value={challenge.c_name} onChange={handleChange} /></p>
                                </div>
                                <div class="read_info">
                                    <div class="info_img">
                                        <img id="thumbnail" src={challenge.c_thumbnails ? `http://localhost:8070${challenge.c_thumbnails}` : "./img/upload.png"} alt="morning"/>
                                        <input type="file" id="uploadInput" name="thumbnail" onChange={handleChange} />
                                    </div>
                                    <div class="info_text">
                                        <p>
                                            <label htmlFor="">참가 인원 : </label>
                                            <input type="number" min="1" value={challenge.c_numberofparticipants} name="c_numberofparticipants" onChange={handleChange} />
                                        </p>
                                        <p>
                                            <label htmlFor="">시작일 :</label>
                                            <input type="date" name="c_startdate" value={challenge.c_startdate} onChange={handleChange} />
                                        </p>
                                        <p>
                                            <label htmlFor="">종료일 :</label>
                                            <input type="date" name="c_enddate" value={challenge.c_enddate} onChange={handleChange} />
                                        </p>
                                        <p>
                                            <label for="">카테고리 :</label>
                                            <select name="c_category" value={challenge.c_category} onChange={handleChange}>
                                                <option value="1">일상</option>
                                                <option value="2">운동</option>
                                                <option value="3">공부</option>
                                                <option value="4">취미</option>
                                            </select>
                                        </p>
                                        <p>
                                            <label for="">참가금 :</label>
                                            <input type="number" name="c_fee" value={challenge.c_fee} onChange={handleChange} />
                                        </p>
                                        <p>
                                            <label for="">필수 등록 사진 개수 :</label>
                                            <input type="number" name="c_numberofphoto" value={challenge.c_numberofphoto} onChange={handleChange}/>
                                        </p>
                                        <p>
                                            인증 타입(사진 or 챌린지) :
                                            <input type="radio" id="c_typeofverify_1" name="c_typeofverify" value="1" checked={challenge.c_typeofverify === 1} onChange={handleChange}/><label for="c_typeofverify_1">사진</label>
                                            <input type="radio" id="c_typeofverify_2" name="c_typeofverify" value="2" checked={challenge.c_typeofverify === 2} onChange={handleChange}/><label for="c_typeofverify_2">메타버스</label>
                                        </p>
                                        <p>
                                            <label for="">빈도 타입 :</label>
                                            <input type="radio" id="c_typeoffrequency_1" name="c_typeoffrequency" value="1" checked={challenge.c_typeoffrequency === 1} onChange={handleChange} /><label for="c_typeoffrequency_1">하루에 N번</label>
                                            <input type="radio" id="c_typeoffrequency_2" name="c_typeoffrequency" value="2" checked={challenge.c_typeoffrequency === 2} onChange={handleChange} /><label for="c_typeoffrequency_2">N일에 한번</label>
                                        </p>
                                        <p>
                                            <label htmlFor="">빈도</label>
                                            <input type="number" name="c_frequency" value={challenge.c_frequency} onChange={handleChange}/>
                                        </p>
                                        <p>
                                            <label htmlFor="">성공점수</label>
                                            <input type="number" name="c_score" value={challenge.c_score} onChange={handleChange}/>
                                        </p>
                                    </div>
                                </div>
                                <div class="read_content">
                                    <textarea name="c_content" id="" cols="30" rows="10" placeholder="내용을 작성하세요..." value={challenge.c_content} onChange={handleChange}/>
                                </div>
                                <div class="read_btn">
                                    <button onClick={()=>updateChallenge(challenge)}>챌린지수정</button>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            {props.footer}
        </>
    )
}

export default ChallengeUpdate;